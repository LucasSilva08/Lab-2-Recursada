using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.SP
{
  public class Durazno:Fruta
  {
    protected int _cantPelusa;

    public string Nombre
    {
      get { return "Durazno"; }
    }
    public override bool TieneCarozo
    {
      get { return true; }
    }

    protected override string FrutaToString()
    {
      return base.FrutaToString() + "/ Tipo :" + this.Nombre + "/ Cantidad de Pelusa :" + this._cantPelusa;
    }

    public Durazno():base()
    {

    }
    public Durazno(string color, double peso, int pelusa):base(peso,color)
    {
      this._cantPelusa = pelusa;
    }
    public override string ToString()
    {
      return this.FrutaToString();
    }
  }
}
