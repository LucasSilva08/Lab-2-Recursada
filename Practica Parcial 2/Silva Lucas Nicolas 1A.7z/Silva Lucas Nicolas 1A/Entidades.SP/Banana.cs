using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.SP
{
  public class Banana: Fruta
  {
    protected string _paisOrigen;

    public string Nombre
    {
      get { return "Banana"; }
    }
    public override bool TieneCarozo
    {
      get { return false; }
    }
    public Banana():base()
    {

    }
    public Banana(string color, double peso, string pais):base(peso,color)
    {
      this._paisOrigen = pais;
    }

    protected override string FrutaToString()
    {
      return base.FrutaToString() + "/ Tipo :" + this.Nombre + "/ Pais de Origen :" + this._paisOrigen;
    }
    public override string ToString()
    {
      return this.FrutaToString();
    }
  }
}
