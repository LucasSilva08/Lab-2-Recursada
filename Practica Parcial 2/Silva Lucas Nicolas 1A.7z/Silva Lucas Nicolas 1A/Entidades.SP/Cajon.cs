using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace Entidades.SP
{
  public delegate void PrecioAlto(object sender);
  public class Cajon<T>:ISerializar
  {
    protected int _capacidad;
    protected List<T> _elementos;
    protected double _precioUnitario;
    public event PrecioAlto EventoPrecio;

    public List<T> Elementos
    {
      get { return this._elementos; }
    }
    public double PrecioTotal
    {
      get
      {
        if(_precioUnitario * this._elementos.Count>55)
        {
          this.EventoPrecio(this);
        }
        
        return _precioUnitario * this._elementos.Count;
      }
    }

    public Cajon()
    {
      this._elementos = new List<T>();
    }
    public Cajon(int capacidad):this()
    {
      this._capacidad = capacidad;
    }
    public Cajon(double precio ,int capacidad):this(capacidad)
    {
      this._precioUnitario = precio;
    }
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("CAJON / Capacidad: " + this._capacidad + "/ Precio unitario: " + this._precioUnitario + "/ Precio Total: " + this.PrecioTotal);
      foreach (T f in this._elementos)
      {
        sb.AppendLine(f.ToString());
      }
      return sb.ToString();
    }

    public bool Xml(string path)
    {
      bool retorno = false;
      try
      {
        XmlSerializer xs = new XmlSerializer(typeof(T));
        StreamWriter sw = new StreamWriter(path);
        xs.Serialize(sw, this);
        sw.Close();
        retorno = true;

      }
      catch(Exception)
      {
        
      }
      return retorno;
    }

    public static Cajon<T> operator +(Cajon<T> c, T f)
    {
      if (c._elementos.Count + 1 <= c._capacidad)
      {
        c._elementos.Add(f);
        
      }
      else
      {
        throw new CajonLlenoException("CAJON LLENO!!!");
      }
      return c;
    }
    public void ManejadorPrecioAlto(object sender)
    {
      StreamWriter sw = new StreamWriter("cajon.txt", true);
      sw.WriteLine(DateTime.Now);
      sw.WriteLine(((Cajon<T>)sender).PrecioTotal);
      sw.Close();
    }
  }
}
