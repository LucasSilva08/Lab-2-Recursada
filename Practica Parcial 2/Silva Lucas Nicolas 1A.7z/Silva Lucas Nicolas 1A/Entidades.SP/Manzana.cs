using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace Entidades.SP
{
  public class Manzana : Fruta,ISerializar,IDeserializar
  {
    protected string _provinciaOrigen;

    public string Nombre
    {
      get { return "Manzana"; }
    }
    public override bool TieneCarozo
    {
      get { return true; }
    }

    public Manzana():base()
    {

    }

    public Manzana(string color, double peso , string provincia):base(peso,color)
    {
      this._provinciaOrigen = provincia;
    }
    protected override string FrutaToString()
    {
      return base.FrutaToString() + "/ Tipo :" + this.Nombre + "/ Provincia :" + this._provinciaOrigen;
    }

    public bool Xml(string path)
    {
      bool retorno = false;
      try
      {
        XmlSerializer xs = new XmlSerializer(typeof(Manzana));
        StreamWriter sw = new StreamWriter(path);
        xs.Serialize(sw, this);
        sw.Close();
        retorno = true;

      }
      catch (Exception)
      {

      }
      return retorno;
    }

    bool IDeserializar.Xml(string path, out Fruta f)
    {
      f = null;
      bool retorno = false;
      try
      {
        XmlSerializer xs = new XmlSerializer(typeof(Manzana));
        StreamReader sr = new StreamReader(path);
        f = (Manzana)xs.Deserialize(sr);
        sr.Close();
        retorno= true;
      }
      catch (Exception )
      {
        
      }
      return retorno;
    }
    public override string ToString()
    {
      return this.FrutaToString();
    }
  }
}
